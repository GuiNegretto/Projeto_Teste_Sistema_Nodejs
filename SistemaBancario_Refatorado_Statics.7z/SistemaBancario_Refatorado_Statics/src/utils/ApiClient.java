package utils;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ApiClient {
    private static final String BASE_URL = "http://localhost:3000"; // troca pelo teu

    public static String get(String endpoint) throws IOException {
        URL url = new URL(BASE_URL + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder response = new StringBuilder();
        String line;

        while ((line = in.readLine()) != null) {
            response.append(line);
        }
        in.close();
        conn.disconnect();
        return response.toString();
    }

    public static String post(String endpoint, String json) {
    	try {
            URL url = new URL(BASE_URL + endpoint);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json"); //;  utf-8
            conn.setDoOutput(true);

            System.out.println("=== POST Request ===");
            System.out.println("URL: " + url);
            System.out.println("JSON enviado: " + json);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = json.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();
            conn.disconnect();
            return response.toString();

        } catch (IOException e) {
            throw new RuntimeException("Erro ao enviar POST para " + endpoint, e);
    	
    } catch (Exception e) {
        System.err.println("Erro inesperado ao enviar POST: " + e);
        e.printStackTrace();
        throw new RuntimeException("Erro inesperado na requisi��o POST", e);
    }
    }
    
    public static String delete(String endpoint) throws Exception {
    	URL url = new URL(BASE_URL + endpoint);
    	HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    	conn.setRequestMethod("DELETE");
    	conn.setRequestProperty("Content-Type", "application/json");
    	return readResponse(conn);
    }
    
    
    private static String readResponse(HttpURLConnection conn) throws IOException {
        BufferedReader in;
        if (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) {
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        
        String inputLine;
        StringBuilder content = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine);
        }
        in.close();
        return content.toString();
    }
    
    public static String put(String endpoint, String json) throws Exception {
        URL url = new URL(BASE_URL + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PUT");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = json.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }
        
        // L� a resposta do servidor
        return readResponse(conn);
    }

    
    
    
}
