import static org.junit.Assert.*;

import org.junit.Test;

import model.Cliente;

public class test {

	private final Cliente cliente = new Cliente(1, "Lucas", 30, "lucas@gmail.com", 123, true);
	
	@Test
    public void getId() {
        assertEquals(1, cliente.getId());
    }
	


}
