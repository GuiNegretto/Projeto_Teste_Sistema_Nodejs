package negocio;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonObject;
import model.Cliente;
import utils.ApiClient;
import java.util.List;

import model.ContaCorrente;

/**
 * Classe de neg�cio para realizar opera��es sobre as contas do banco.
 * 
 */
public class GerenciadoraContas {
	private final Gson gson = new Gson();
	
	public ContaCorrente pesquisaConta(int id) throws Exception {
        String resp = ApiClient.get("/contas/" + id);
        return gson.fromJson(resp, ContaCorrente.class);
    }

    public List<ContaCorrente> getContas() throws Exception {
        String resp = ApiClient.get("/contas");
        return gson.fromJson(resp, new TypeToken<List<ContaCorrente>>(){}.getType());
    }

    public ContaCorrente adicionaConta(ContaCorrente conta){
    	
        String json = gson.toJson(conta);

        String resp = ApiClient.post("/contas", json);

        ContaCorrente contaCriada = gson.fromJson(resp, ContaCorrente.class);
        return contaCriada;
    }
    


    public void removeConta(int id) throws Exception {
        ApiClient.delete("/contas/" + id);
    }
	/**
	 * Informa se uma determinada conta est� ativa ou n�o.
	 * @param idConta ID da conta cujo status ser� verificado
	 * @return true se a conta est� ativa. False, caso contr�rio. 
	 * @throws Exception 
	 */
	public boolean contaAtiva (int idConta) throws Exception {
			ContaCorrente conta = this.pesquisaConta(idConta);
				if(conta.isAtiva()){
					return true;
				}
		
		return false;
	}
	
	/**
	 * Transfere um determinado valor de uma conta Origem para uma conta Destino.
	 * Caso n�o haja saldo suficiente, o valor n�o ser� transferido.
	 * 
	 * @param idContaOrigem conta que ter� o valor deduzido
	 * @param valor valor a ser transferido
	 * @param idContaDestino conta que ter� o valor acrescido
	 * @return true, se a transfer�ncia foi realizada com sucesso.
	 * @throws Exception 
	 */
	public boolean transfereValor (int idContaOrigem, double valor, int idContaDestino) throws Exception {

	    if (valor <= 0) {
	        throw new IllegalArgumentException("O valor da transfer�ncia deve ser maior que zero.");
	    }

	    try {

	        JsonObject jsonSaque = new JsonObject();
	        jsonSaque.addProperty("valor", valor);
	        
	        String jsonSaqueStr = jsonSaque.toString();

	        ApiClient.put("/contas/" + idContaOrigem + "/saque", jsonSaqueStr);

	        JsonObject jsonDeposito = new JsonObject();
	        jsonDeposito.addProperty("valor", valor);

	        String jsonDepositoStr = jsonDeposito.toString();
	        
	        ApiClient.put("/contas/" + idContaDestino + "/deposito", jsonDepositoStr);
	        
	        return true;
	        
	    } catch (Exception e) {
	        System.err.println("Erro ao realizar a transfer�ncia: " + e.getMessage());
	        return false;
	    }
	}
	
}
