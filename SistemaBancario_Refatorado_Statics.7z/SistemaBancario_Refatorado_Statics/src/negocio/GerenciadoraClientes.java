package negocio;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import model.Cliente;
import utils.ApiClient;
import java.util.List;

import model.Cliente;

/**
 * Classe de neg�cio para realizar opera��es sobre os clientes do banco.
 * 
 */
public class GerenciadoraClientes {

	/*private List<Cliente> clientesDoBanco;

	public GerenciadoraClientes(List<Cliente> clientesDoBanco) {
		this.clientesDoBanco = clientesDoBanco;
	}
	
	*//**
	 * Retorna uma lista com todos os clientes do banco.
	 * @return lista com todos os clientes do banco
	 *//*
	public List<Cliente> getClientesDoBanco() {
		return clientesDoBanco;
	}
	
	*//**
	 * Pesquisa por um cliente a partir do seu ID.
	 * @param idCliente id do cliente a ser pesquisado
	 * @return o cliente pesquisado ou null, caso n�o seja encontrado
	 *//*
	public Cliente pesquisaCliente (int idCliente) {

		for (Cliente cliente : clientesDoBanco) {
			if(cliente.getId() == idCliente)
				return cliente;
		}
		return null;
	}
	
	*//**
	 * Adiciona um novo cliente � lista de clientes do banco.
	 * @param novoCliente novo cliente a ser adicionado
	 *//*
	public void adicionaCliente (Cliente novoCliente) {
		clientesDoBanco.add(novoCliente);
	}

	*//**
	 * Remove cliente da lista de clientes do banco.
	 * @param idCliente ID do cliente a ser removido 
	 * @return true se o cliente foi removido. False, caso contr�rio.
	 *//*
	public boolean removeCliente (int idCliente) {
		boolean clienteRemovido = false;
		
		for (int i = 0; i < clientesDoBanco.size(); i++) {
			Cliente cliente = clientesDoBanco.get(i);
			if(cliente.getId() == idCliente){
				clientesDoBanco.remove(i);
				clienteRemovido = true;
				break;
			}
		}
		
		return clienteRemovido;
	}*/
	
	
    private final Gson gson = new Gson();

    public Cliente pesquisaCliente(int id) throws Exception {
        String resp = ApiClient.get("/clientes/" + id);
        return gson.fromJson(resp, Cliente.class);
    }

    public List<Cliente> getClientes() throws Exception {
        String resp = ApiClient.get("/clientes");
        return gson.fromJson(resp, new TypeToken<List<Cliente>>(){}.getType());
    }

    public Cliente adicionaCliente(Cliente cliente) throws Exception {
        String json = gson.toJson(cliente);
        String resp = ApiClient.post("/clientes", json);
        return gson.fromJson(resp, Cliente.class);
    }

    public void removeCliente(int id) throws Exception {
        ApiClient.delete("/clientes/" + id);
    }

	/**
	 * Informa se um determinado cliente est� ativo ou n�o.
	 * @param idCliente ID do cliente cujo status ser� verificado
	 * @return true se o cliente est� ativo. False, caso contr�rio. 
	 * @throws Exception 
	 */
	public boolean clienteAtivo (int idCliente) throws Exception {
		
		Cliente cliente = this.pesquisaCliente(idCliente);
		if(cliente.isAtivo()){
			return true;
		}
		return false;
	}
	
	public Cliente alteraStatusCliente(int idCliente) throws Exception {

	    Cliente cliente = this.pesquisaCliente(idCliente);
	    
	    if (cliente == null) {
	        throw new Exception("Cliente n�o encontrado.");
	    }
	    
	    cliente.setAtivo(!cliente.isAtivo());
	    
	    String json = gson.toJson(cliente);
	    
	    String resp = ApiClient.put("/clientes/" + idCliente + "/status", json);
	    
	    return gson.fromJson(resp, Cliente.class);
	}

	/**
	 * Limpa a lista de clientes, ou seja, remove todos eles. 
	 */
/*	public void limpa() {
		this.clientesDoBanco.clear();
	}*/
	
	/**
	 * Valida se a idade do cliente est� dentro do intervalo permitido (18 - 65).
	 * @param idade a idade do poss�vel novo cliente
	 */
	public boolean validaIdade(int idade) throws IdadeNaoPermitidaException {
	
		if(idade < 18 || idade > 65)
			throw new IdadeNaoPermitidaException("A idade do cliente precisa estar entre 18 e 65 anos.");
		
		return true;
	}
	
}
