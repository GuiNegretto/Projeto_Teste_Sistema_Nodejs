package negocio;

import java.util.Scanner;

import com.google.gson.Gson;

import model.Cliente;
import model.ContaCorrente;

public class Main {

	private GerenciadoraClientes gerClientes = new GerenciadoraClientes();
	private GerenciadoraContas gerContas = new GerenciadoraContas();
	 
	
	public static void main(String[] args) {
		Main app = new Main();
		
		//app.inicializaSistemaBancario();
		
		Scanner sc = new Scanner(System.in);
		boolean continua = true;
		 Gson gson = new Gson();
		
		
		
		while (continua){
			
			app.printMenu();
			
			int opcao = sc.nextInt();
			
			switch (opcao) {
			// Consultar por um cliente
			case 1:
				System.out.print("Digite o ID do cliente: ");
				int idCliente = sc.nextInt();
				Cliente cliente = null;
				try{
					cliente = app.gerClientes.pesquisaCliente(idCliente);
				} catch (Exception e) {
				    System.err.println("Erro ao buscar cliente: " + e.getMessage());
				}
				
				
				
				if(cliente != null)
					System.out.println(cliente.toString());
				else
					System.out.println("Cliente n�o encontrado!");
				
				app.pulalinha();
				break;

			// Consultar por uma conta corrente
			case 2:
				System.out.print("Digite o ID da conta: ");
				int idConta = sc.nextInt();
				ContaCorrente conta = null;
				try{
					conta = app.gerContas.pesquisaConta(idConta);
				} catch (Exception e) {
					System.err.println("Erro ao buscar conta: " + e.getMessage());
				}
				
				if(conta != null)
					System.out.println(conta.toString());
				else
					System.out.println("Conta n�o encontrado!");
				
				app.pulalinha();
				break;

			// Ativar um cliente
			case 3:
				
				System.out.print("Digite o ID do cliente: ");
				int idCliente2 = sc.nextInt();
				Cliente cliente2 = null;
				
				try{
					cliente2 = app.gerClientes.alteraStatusCliente(idCliente2);
				} catch (Exception e) {
					System.err.println("Erro ao buscar cliente: " + e.getMessage());
				}
				
				if(cliente2 != null){
					cliente2.setAtivo(true);
					System.out.println("Cliente ativado com sucesso!");
				}
				else
					System.out.println("Cliente n�o encontrado!");
			
				app.pulalinha();
				break;
				
			// Desativar um cliente
			case 4:
				
				System.out.print("Digite o ID do cliente: ");
				int idCliente3 = sc.nextInt();
				Cliente cliente3 = null;
				
				try{
					cliente3 = app.gerClientes.alteraStatusCliente(idCliente3);
				} catch (Exception e) {
					System.err.println("Erro ao buscar cliente: " + e.getMessage());
				}
				
				if(cliente3 != null){
					cliente3.setAtivo(false);
					System.out.println("Cliente desativado com sucesso!");
				}
				else
					System.out.println("Cliente n�o encontrado!");
				
				app.pulalinha();
				break;
			
				
				// Transferir valor
		    case 5:
		        System.out.print("Digite o ID da conta de origem: ");
		        int idContaOrigem = sc.nextInt();
		        System.out.print("Digite o ID da conta de destino: ");
		        int idContaDestino = sc.nextInt();
		        System.out.print("Digite o valor a ser transferido: ");
		        double valorTransferencia = sc.nextDouble();

		        try {
		            boolean sucesso = app.gerContas.transfereValor(idContaOrigem, valorTransferencia, idContaDestino);
		            if (sucesso) {
		                System.out.println("Transfer�ncia realizada com sucesso!");
		            } else {
		                System.out.println("N�o foi poss�vel realizar a transfer�ncia.");
		            }
		        } catch (Exception e) {
		            System.err.println("Erro ao transferir valor: " + e.getMessage());
		        }
		        app.pulalinha();
		        break;

		    // Adicionar um novo cliente
		    case 6:
		        System.out.println("Digite o ID do novo cliente:");
		        int idNovoCliente = sc.nextInt();
		        sc.nextLine(); // Consume newline
		        System.out.println("Digite o nome do cliente:");
		        String nomeNovoCliente = sc.nextLine();
		        System.out.println("Digite a idade do cliente:");
		        int idadeNovoCliente = sc.nextInt();
		        sc.nextLine(); // Consume newline
		        System.out.println("Digite o email do cliente:");
		        String emailNovoCliente = sc.nextLine();
		        System.out.println("Digite o ID da conta corrente associada:");
		        int idContaNovoCliente = sc.nextInt();

		        try {
		            Cliente novoCliente = new Cliente(idNovoCliente, nomeNovoCliente, idadeNovoCliente, emailNovoCliente, idContaNovoCliente, true);
		            app.gerClientes.adicionaCliente(novoCliente);
		            System.out.println("Cliente adicionado com sucesso!");
		        } catch (Exception e) {
		            System.err.println("Erro ao adicionar cliente: " + e.getMessage());
		        }
		        app.pulalinha();
		        break;

		    // Adicionar uma nova conta
		    case 7:
		        System.out.println("Digite o ID da nova conta:");
		        int idNovaConta = sc.nextInt();
		        System.out.println("Digite o saldo inicial:");
		        double saldoNovaConta = sc.nextDouble();

		        try {
		            ContaCorrente novaConta = new ContaCorrente(idNovaConta, saldoNovaConta, true);
		            app.gerContas.adicionaConta(novaConta);
		            System.out.println("Conta adicionada com sucesso!");
		        } catch (Exception e) {
		        	System.out.println("Mensagem: " + e.getMessage());
		        }
		        
		       
		        app.pulalinha();
		        break;

		    // Remover um cliente
		    case 8:
		        System.out.print("Digite o ID do cliente a ser removido: ");
		        int idClienteRemover = sc.nextInt();
		        try {
		            app.gerClientes.removeCliente(idClienteRemover);
		            System.out.println("Cliente removido com sucesso!");
		        } catch (Exception e) {
		            System.err.println("Erro ao remover cliente: " + e.getMessage());
		        }
		        app.pulalinha();
		        break;

		    // Remover uma conta
		    case 9:
		        System.out.print("Digite o ID da conta a ser removida: ");
		        int idContaRemover = sc.nextInt();
		        try {
		            app.gerContas.removeConta(idContaRemover);
		            System.out.println("Conta removida com sucesso!");
		        } catch (Exception e) {
		            System.err.println("Erro ao remover conta: " + e.getMessage());
		        }
		        app.pulalinha();
		        break;
		        
		    // Sair
		    case 10:
		        continua = false;
		        System.out.println("################# Sistema encerrado #################");
		        break;
				
			default:
				System.out.println("Op��o inv�lida. Tente novamente.");
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println();
				break;
				
			} 
			
		}
	sc.close();
		
	}

	private void pulalinha() {
		System.out.println("\n");
	}

	/**
	 * Imprime menu de op��es do nosso sistema banc�rio
	 */
	private void printMenu() {
		
		System.out.println("O que voc� deseja fazer? \n");
		System.out.println("1) Consultar por um cliente");
		System.out.println("2) Consultar por uma conta corrente");
		System.out.println("3) Ativar um cliente");
		System.out.println("4) Desativar um cliente");
	    System.out.println("5) Transferir valor");
	    System.out.println("6) Adicionar um novo cliente");
	    System.out.println("7) Adicionar uma nova conta");
	    System.out.println("8) Remover um cliente");
	    System.out.println("9) Remover uma conta");
	    System.out.println("10) Sair");
		System.out.println();
		
	}

	/**
	 * M�todo que cria e insere algumas contas e clientes no sistema do banco,
	 * apenas para realiza��o de testes manuais atrav�s do m�todo main acima.
	 */
/*	private void inicializaSistemaBancario() {
		// criando lista vazia de contas e clientes
		List<ContaCorrente> contasDoBanco = new ArrayList<>();
		List<Cliente> clientesDoBanco = new ArrayList<>();
		
		// criando e inserindo duas contas na lista de contas correntes do banco
		ContaCorrente conta01 = new ContaCorrente(1, 0, true);
		ContaCorrente conta02 = new ContaCorrente(2, 0, true);
		contasDoBanco.add(conta01);
		contasDoBanco.add(conta02);
		
		// criando dois clientes e associando as contas criadas acima a eles
		Cliente cliente01 = new Cliente(1, "Maria Silva", 31, "mariasilva@gmail.com", conta01.getId(), true);
		Cliente cliente02 = new Cliente(2, "Felipe Augusto", 34, "felipeaugusto@gmail.com", conta02.getId(), true);
		// inserindo os clientes criados na lista de clientes do banco
		clientesDoBanco.add(cliente01);
		clientesDoBanco.add(cliente02);
		
		gerClientes = new GerenciadoraClientes(clientesDoBanco);
		gerContas = new GerenciadoraContas(contasDoBanco);
		
	}*/
	
}

